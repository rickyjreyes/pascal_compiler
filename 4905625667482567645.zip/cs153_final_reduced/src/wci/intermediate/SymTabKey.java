package wci.intermediate;

/**
 * <h1>SymTabKey</h1>
 *
 * <p>The interface for an attribute key of a symbol table entry.</p>
 *
 * <p>Copyright (c) 2009 by Ronald Mak</p>
 * <p>For instructional purposes only.  No warranties.</p>
 */
public interface SymTabKey
{
}
